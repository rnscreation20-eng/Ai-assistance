# AURA AI — Architecture Decision Record (Phase 1)

Status: DRAFT — covers items 1–6 of the requested "first task." Nothing here has been
performance-tested on a physical device yet; treat all numeric targets as goals, not
measurements, until Phase 6 testing.

---

## 1. Rendering Architecture Decision

### Options evaluated

| Option | Avatar/animation quality | Android integration risk | App size | Maintenance | Battery/perf |
|---|---|---|---|---|---|
| **Unity embedded as an Android library (Unity-as-a-Library)** | Best-in-class: full Animator/Timeline, blendshapes, SkinnedMeshRenderer visemes | High — UaaL has real bridging quirks (activity lifecycle, back-stack, memory ownership between the Unity `UnityPlayer` and the host Activity are a known source of crashes if not handled carefully) | Large (+30–60MB typical for a stripped IL2CPP build) | Two build toolchains, two sets of release pipelines | Good if tuned, but GC/physics overhead if not careful |
| **React Native + WebGL avatar (three.js) inside a WebView/GL surface** | Good — glTF + morph targets support visemes and blendshapes fine at this scope | Medium — WebView GL performance varies by device, but no cross-runtime lifecycle bridging | Small (avatar is just a glTF + JS) | Single JS/TS codebase | Good — no second engine running in parallel |
| **Native Android (Filament or SceneView, glTF import, Kotlin)** | Good — Filament (Google's PBR engine) supports morph target animation and is designed for exactly this "avatar in an app" use case | Low — first-class Android library, no cross-engine bridge | Small (~5–10MB) | Single Kotlin codebase, single build | Best — native GPU path, no WebView/JS overhead |

### Decision

**Recommended: Native Android with Filament (or SceneView, which wraps Filament) using
a glTF avatar with morph-target blendshapes**, not Unity-as-a-Library.

Reasoning:
- The character doesn't need a full game engine — no physics simulation, no level
  design, no complex gameplay logic. What's needed is: load one rigged character,
  play a handful of animation clips, drive ~10–15 blendshapes from audio, and render
  it behind a normal Android UI.
- Unity-as-a-Library is the highest-risk item in this whole project from an
  integration-stability standpoint. It's absolutely capable of working, but it adds a
  second runtime, a second build pipeline, and a well-documented set of lifecycle
  edge cases (Activity re-creation, back button handling, memory not being released
  when the Unity view is destroyed) that would consume a disproportionate share of
  Phase 1–3 just to get stable — before any avatar work begins.
- Filament is Google's own production rendering engine (used in Android's Scene
  Viewer / AR features), has an official Kotlin/Android artifact on Maven, supports
  glTF import and morph-target (blendshape) animation directly, and avoids a second
  engine entirely.
- If, after the Phase 3 PoC, Filament's animation tooling proves insufficient for the
  facial rig complexity wanted, the fallback is React Native + three.js (same glTF
  asset, different renderer) — not Unity. This keeps the asset pipeline (glTF +
  blendshapes) valid across either fallback path.

**This is a Phase-1 recommendation, not a locked-in irreversible choice** — it should
be validated with the minimal avatar PoC in Phase 3 before committing further.

---

## 2. Avatar Character Specification

Status: **specification only** — no 3D asset has been created. A glTF/GLB model with
a facial blendshape rig will need to be produced (e.g., commissioned, or built in
Blender/Character Creator/Ready Player Me-style pipeline) or licensed from an asset
source that permits redistribution in a commercial app. Nothing below should be read
as "this model exists."

- **Style**: stylized anime-realism, adult female presentation, consistent identity
  across sessions (same face/hair/outfit every launch — not regenerated).
- **Face**: large expressive eyes with a 2-bone eyelid blink rig, gaze-target bone
  (look-at constraint), and a blendshape set covering at least: jaw-open, mouth-wide,
  mouth-narrow, smile, frown, brow-up, brow-down, cheek-puff — enough to cover both
  visemes and the 7 emotion states in §8 of the brief.
- **Hair**: single distinctive hairstyle, low-count physics bones (4–8 max) or
  baked secondary motion instead of full cloth/hair simulation, to stay
  mobile-friendly.
- **Outfit**: modest, modern silhouette, white/lavender/soft-blue palette, no
  cloth simulation — rigid-attached to the body mesh.
- **Budget targets** (goals, to be verified against real device profiling in Phase
  6): 15–30k triangles, 1–2 material slots, 1k–2k texture atlas.

Until a real asset exists, Phase 1–2 will render a **clearly labeled placeholder**
(a simple procedural shape or stand-in glTF) so the animation *state machine* and
*voice pipeline* can be built and tested independently of asset production.

---

## 3. Voice AI Proof-of-Concept Plan

- **Provider**: OpenAI Realtime API as primary (per the brief). Before writing
  integration code, Phase 2 starts by pulling OpenAI's current Realtime API docs
  (event names, session model, supported languages) rather than assuming API shapes
  from training data — the brief explicitly flags this as a risk area, and it's a
  correct concern: realtime/streaming APIs change quickly.
- **Odia risk flag (real, up front)**: mainstream TTS/ASR providers have historically
  had much weaker Odia coverage than Hindi/English. This needs to be verified against
  current provider docs before Phase 2 is considered "done" for Odia — if the primary
  provider can't do Odia at acceptable quality, the documented fallback is a
  secondary provider (e.g., Azure Speech, which has broader Indic language coverage)
  used specifically for the Odia path, with this clearly surfaced in-app rather than
  silently degrading.
- **PoC scope** (small and verifiable, per the brief's instruction not to build a
  monolith): mic capture → stream to backend → backend opens short-lived Realtime
  session → audio streams back → played on device → interruption (barge-in) stops
  playback and reopens the mic. No avatar, no UI polish — just proving the audio
  round-trip and interruption handling work before layering anything else on top.

---

## 4. Backend & Security Architecture

- **Stack**: Node.js + TypeScript, Supabase (Postgres + Auth).
- **Key rule from the brief, and it's the right one**: the Android app **never**
  holds a permanent provider API key. The backend mints a short-lived session/token
  (however the chosen provider's realtime API structures ephemeral credentials — to
  be confirmed against current provider docs in Phase 2) after verifying a Supabase
  Auth JWT from the client.
- **Auth flow**: Supabase Auth on-device → JWT sent to backend on every request →
  backend verifies JWT signature/expiry → backend, not the client, decides what the
  user is authorized to do → backend requests a fresh provider session and hands
  back only what the client needs to stream audio.
- **Data model** (Postgres, RLS-enforced so a user can only ever read/write their own
  rows): `users`, `user_preferences` (language, voice settings), `conversation_sessions`,
  `messages` (text transcript only — **no raw audio stored by default**, matching the
  brief), `usage_events` (for rate limiting).
- **Rate limiting**: per-user request/session caps enforced server-side (e.g., token
  bucket in Postgres or Redis), not client-side.

---

## 5. What Phase 1 actually delivers (this drop)

Per "proceed in small, verifiable steps" — this first drop is intentionally scoped to
just the **UI shell + mocked avatar state machine**, nothing voice- or 3D-related yet:

- A real, runnable Android (Kotlin + Jetpack Compose) project.
- An `AvatarState` enum (`IDLE`, `LISTENING`, `THINKING`, `SPEAKING`, `INTERRUPTED`,
  `ERROR`, `DISCONNECTED`) driven by a `ViewModel`, matching §4 of the brief.
- A main avatar screen with a **placeholder** avatar (a colored circle, clearly
  labeled as a placeholder) that visibly changes per state, plus mic/mute/stop
  buttons that drive the state machine — all mocked, no real audio or network yet.
- No voice, no 3D, no backend, no auth — those are Phases 2, 3, and 5 and depend on
  provider-doc verification and asset production described above, so building them
  now would mean guessing at APIs that need to be checked first.

See the included project's `README.md` for exact run instructions.

## Next steps (not yet started)
1. Pull current OpenAI Realtime API docs → build the voice PoC (Phase 2).
2. Produce or source the glTF avatar asset → Filament PoC (Phase 3).
3. Wire audio → viseme mapping (Phase 4).
4. Supabase project + backend session-minting endpoint (Phase 5).
