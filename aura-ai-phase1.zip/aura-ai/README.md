# AURA AI — Phase 1 (UI shell + mocked avatar state machine)

## What this is
A real, runnable Android app (Kotlin + Jetpack Compose). It has **no voice, no 3D
avatar, no backend, no auth** yet — see `ARCHITECTURE_DECISION_RECORD.md` for why
those are sequenced into later phases rather than guessed at now.

## What's real vs. mocked in this drop
| Piece | Status |
|---|---|
| `AvatarState` enum + `AvatarStateMachine` transition rules | Real, unit-testable logic |
| `AvatarViewModel` | Real — owns state, rejects invalid transitions |
| Main screen UI (Compose) | Real UI, renders and responds to taps |
| Avatar itself | **Mocked** — a colored circle, explicitly labeled in-app as a placeholder |
| Mic / voice / language / lip-sync | **Not implemented** — buttons simulate the state changes a real voice session would trigger, so the state machine can be validated independently of the provider integration |
| Backend / auth / conversation history | **Not implemented** (Phase 5) |

## Easiest option: let GitHub build the APK for you
A workflow is included at `.github/workflows/build-apk.yml`. To use it:
1. Create a **new GitHub repository** and push this whole `aura-ai/` folder to it
   (e.g. `git init && git add . && git commit -m "phase 1" && git remote add origin <your repo url> && git push -u origin main`).
2. On GitHub, go to the **Actions** tab of your repo — the workflow runs
   automatically on push (or click "Run workflow" to trigger it manually).
3. Once it finishes (a few minutes), open the finished run → scroll to
   **Artifacts** → download `aura-ai-debug-apk`. That's a zip containing
   `app-debug.apk`.
4. Transfer the APK to your phone (email it to yourself, Google Drive, USB,
   whatever's easiest) and tap it to install. You'll need to allow
   "Install unknown apps" for whichever app you used to open it.

No Android Studio needed for this path — GitHub's own servers do the build.

## Manual option: build locally in Android Studio
1. Install [Android Studio](https://developer.android.com/studio) (Koala or newer).
2. `File → Open` → select the `aura-ai/` folder.
3. Let Gradle sync (it will download the Android Gradle Plugin, Kotlin, and
   Compose dependencies from Google/Maven Central — needs internet access).
4. Create/start an emulator (API 26+) via Device Manager, or plug in a physical
   Android device with USB debugging enabled.
5. Click Run (▶). The app launches to the AURA AI screen with a lavender
   placeholder circle and a row of buttons that simulate state changes.

This was written and organized here, but **not compiled/run in this environment**
(no Android SDK/emulator available in this sandbox) — Android Studio's Gradle
sync and build are what will surface any real compile errors, so treat first
run as the actual verification step, per the brief's "verify before claiming
it works" rule.

## Suggested first check when you run it
Tap through: Mic tap → THINKING → SPEAKING → Interrupt → Stop. Confirm the
circle's color and label change each time, and that the state machine
rejects a nonsensical jump (e.g. tap "Simulate error" right after launch —
`IDLE → ERROR` isn't in the allowed transition table, so it should show the
"not valid" message instead of changing state).

## Next steps
See `ARCHITECTURE_DECISION_RECORD.md` §5 "Next steps" — Phase 2 is the voice
proof-of-concept, gated on pulling current OpenAI Realtime API docs first.
