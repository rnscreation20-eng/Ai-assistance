package com.auraai.app.state

/**
 * Avatar animation states, per ARCHITECTURE_DECISION_RECORD.md §5 / brief §4.
 *
 * Phase 1: this drives ONLY a placeholder UI (a colored circle). No animation
 * clips, no 3D avatar, no audio are wired up yet — that's Phase 2 (voice) and
 * Phase 3 (3D avatar) work, once the Realtime API docs and the avatar asset
 * exist respectively.
 */
enum class AvatarState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    INTERRUPTED,
    ERROR,
    DISCONNECTED
}

/**
 * Explicit allowed transitions, so the UI can never be pushed into a state
 * that doesn't make sense (e.g. SPEAKING -> LISTENING with no THINKING step
 * in between should still be *possible* for barge-in, but ERROR should only
 * be reachable from an active state, not from IDLE).
 *
 * This is intentionally conservative for Phase 1; it will be revisited once
 * real voice events (Phase 2) exist to drive it instead of button taps.
 */
object AvatarStateMachine {
    fun canTransition(from: AvatarState, to: AvatarState): Boolean {
        if (from == to) return true
        return when (from) {
            AvatarState.IDLE -> to in setOf(AvatarState.LISTENING, AvatarState.DISCONNECTED)
            AvatarState.LISTENING -> to in setOf(
                AvatarState.THINKING, AvatarState.INTERRUPTED, AvatarState.ERROR, AvatarState.IDLE
            )
            AvatarState.THINKING -> to in setOf(
                AvatarState.SPEAKING, AvatarState.ERROR, AvatarState.IDLE
            )
            AvatarState.SPEAKING -> to in setOf(
                AvatarState.LISTENING, AvatarState.INTERRUPTED, AvatarState.IDLE, AvatarState.ERROR
            )
            AvatarState.INTERRUPTED -> to in setOf(AvatarState.LISTENING, AvatarState.IDLE)
            AvatarState.ERROR -> to in setOf(AvatarState.IDLE, AvatarState.DISCONNECTED)
            AvatarState.DISCONNECTED -> to in setOf(AvatarState.IDLE)
        }
    }
}
