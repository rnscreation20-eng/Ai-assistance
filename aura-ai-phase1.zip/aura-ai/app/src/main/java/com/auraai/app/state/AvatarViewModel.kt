package com.auraai.app.state

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

/**
 * Owns the current AvatarState. In Phase 1 the state is only ever changed by
 * mock UI buttons (see MainScreen.kt). In Phase 2 this will instead be driven
 * by real voice-session events (mic opened, turn detected, provider audio
 * streaming, interruption, connection lost) from the voice provider client —
 * none of which exists yet.
 */
class AvatarViewModel : ViewModel() {
    var state by mutableStateOf(AvatarState.IDLE)
        private set

    var lastTransitionRejected by mutableStateOf(false)
        private set

    fun requestTransition(to: AvatarState) {
        if (AvatarStateMachine.canTransition(state, to)) {
            state = to
            lastTransitionRejected = false
        } else {
            // Invalid transitions are surfaced, not silently swallowed or
            // silently forced through.
            lastTransitionRejected = true
        }
    }
}
