package com.auraai.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.auraai.app.state.AvatarState
import com.auraai.app.state.AvatarViewModel

// Palette per ARCHITECTURE_DECISION_RECORD.md §2 (white / lavender / soft blue)
private val Lavender = Color(0xFFB39DDB)
private val SoftBlue = Color(0xFFA7C7E7)
private val BgWhite = Color(0xFFFAFAFF)

private fun colorFor(state: AvatarState): Color = when (state) {
    AvatarState.IDLE -> Lavender
    AvatarState.LISTENING -> SoftBlue
    AvatarState.THINKING -> Color(0xFFD1C4E9)
    AvatarState.SPEAKING -> Color(0xFF9FA8DA)
    AvatarState.INTERRUPTED -> Color(0xFFFFCC80)
    AvatarState.ERROR -> Color(0xFFEF9A9A)
    AvatarState.DISCONNECTED -> Color(0xFFBDBDBD)
}

@Composable
fun MainScreen(viewModel: AvatarViewModel = viewModel()) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgWhite)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "AURA AI",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF5E4B8B)
        )
        Text(
            "Phase 1 — placeholder avatar, mocked states only",
            fontSize = 13.sp,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // PLACEHOLDER AVATAR — not the final 3D character. This circle only
        // exists to prove the state machine and UI shell work end-to-end.
        Box(
            modifier = Modifier
                .size(220.dp)
                .clip(CircleShape)
                .background(colorFor(viewModel.state)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                viewModel.state.name,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        if (viewModel.lastTransitionRejected) {
            Text(
                "That state change isn't valid from here — ignored.",
                color = Color(0xFFB71C1C),
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // Mock controls standing in for real mic/voice events (Phase 2).
        FlowRow {
            StateButton("Mic tap (→ LISTENING)") {
                viewModel.requestTransition(AvatarState.LISTENING)
            }
            StateButton("→ THINKING") {
                viewModel.requestTransition(AvatarState.THINKING)
            }
            StateButton("→ SPEAKING") {
                viewModel.requestTransition(AvatarState.SPEAKING)
            }
            StateButton("Interrupt") {
                viewModel.requestTransition(AvatarState.INTERRUPTED)
            }
            StateButton("Stop (→ IDLE)") {
                viewModel.requestTransition(AvatarState.IDLE)
            }
            StateButton("Simulate error") {
                viewModel.requestTransition(AvatarState.ERROR)
            }
            StateButton("Simulate disconnect") {
                viewModel.requestTransition(AvatarState.DISCONNECTED)
            }
        }
    }
}

@Composable
private fun StateButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.padding(4.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Lavender)
    ) {
        Text(label, fontSize = 12.sp)
    }
}

// Minimal flow-wrap row so buttons don't overflow narrow screens; avoids
// pulling in an extra layout dependency for Phase 1.
@Composable
private fun FlowRow(content: @Composable () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        content()
    }
}
